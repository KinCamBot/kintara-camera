const btn = document.getElementById('toggle');
const note = document.getElementById('note');
const PLAY = /:\/\/kintara\.gg\/play/i;
async function activeTab(){ const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); return t; }
async function runInPage(func){
  const t = await activeTab();
  if (!t || !PLAY.test(t.url || '')) return { noTab: true };
  try { const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: 'MAIN', func }); return { result: r ? r.result : undefined }; }
  catch (e) { return { error: String(e.message) }; }
}
async function refresh(){
  const t = await activeTab();
  if (!t || !PLAY.test(t.url || '')) { btn.textContent = 'Open kintara.gg/play'; btn.disabled = true; btn.classList.add('off'); note.textContent = 'KinCam only runs in the game.'; return; }
  const { result } = await runInPage(() => (typeof window.__kxPanelVisible === 'function' ? window.__kxPanelVisible() : null));
  btn.disabled = false;
  if (result === null || result === undefined) { btn.textContent = 'Refresh the game tab'; btn.classList.add('off'); note.textContent = 'KinCam is still loading.'; return; }
  btn.textContent = result ? 'Hide KinCam' : 'Show KinCam';
  btn.classList.toggle('off', !result);
  note.textContent = result ? 'Panel is showing.' : 'Panel is hidden.';
}
btn.addEventListener('click', async () => {
  const { result } = await runInPage(() => (typeof window.__kxPanelVisible === 'function' ? window.__kxPanelVisible() : null));
  if (result === null || result === undefined) { refresh(); return; }
  await runInPage(result ? (() => { if (window.__kxPanelHide) window.__kxPanelHide(); }) : (() => { if (window.__kxPanelShow) window.__kxPanelShow(); }));
  refresh();
});
refresh();